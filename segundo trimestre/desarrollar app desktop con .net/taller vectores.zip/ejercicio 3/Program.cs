﻿using System;

namespace ejercicio_3
{
    class Program
    {
        static void Main(string[] args)
        /*Llenar un vector con los 10 primeros múltiplos de 3 y luego sume los elementos del vector.
          Mostrar la suma de los elementos.
               */
        {
            int n,num,suma;
            Console.WriteLine("ingresa el tamaño del vector");
            n = int.Parse(Console.ReadLine());
            int[] vector = new int[n];
            num = 3;
            suma = 0;
            for (int i=0;i<n;i++)
            {
                vector[i] = num;
                num = num + 3;
                suma = suma + num;
            }

            for (int i = 0; i < n; i++)
            {
                Console.WriteLine(vector[i]);
               
            }
            Console.WriteLine("suma la suma de los vectores de 3 son:"+suma);

        }
    }
}
