﻿using System;

namespace ejercicio_14
{
    class Program
    {
        static void Main(string[] args)
        {
            /*14. Elabore un algoritmo que lea un vector de N elementos. Si el número de elementos es par
            intercambiar el elemento i-ésimo por el elemento i-ésimo + 1.Mostrar el vector final.Si el
            número de elementos es impar, indicarlo en un mensaje que no es posible hacer el
             intercambio y forzar al usuario hasta que digite un número de elementos par.
            */
            int n, num, ax = 0,t=0;
            Console.WriteLine("ingresa el tamaño del vector");
            n = int.Parse(Console.ReadLine());
            int[] vector1 = new int[n];
            //llenar
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine("ingrese un numero");
                num = int.Parse(Console.ReadLine());
                vector1[i] = num;
            }
                //mostrar
                Console.WriteLine("el vector es:");
                 ax = vector1[0];
            for (int i = 0; i < n; i++)
                {
                    Console.WriteLine(vector1[i]);
                }
            for (int i = 0; i < n; i++)
            {
               
                if (n % 2 == 0)
                {
                    if (i+t>-n)
                    {
                        vector1[0] = vector1[i];
                    }

                else 
                    {
                        vector1[i] = vector1[i + 1];
                    }
                }

                else
                {
                    Console.WriteLine("no es posible hacer el intercambio");
                }
                
            }
            //mostrar
            Console.WriteLine("el vector es:");
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine(vector1[i]);
            }

        }
    }
}
