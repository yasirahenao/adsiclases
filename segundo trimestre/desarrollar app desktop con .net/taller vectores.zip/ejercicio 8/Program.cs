﻿using System;
using System.Runtime.InteropServices;

namespace ejercicio_8
{
    class Program
    {
        static void Main(string[] args)
        {
            // Se tiene un vector con las notas de un grupo de 30 estudiantes.Hallar y mostrar la nota
            //más alta y la más baja, cuántas personas perdieron y la nota promedio del grupo.
            int n,pp;
            float nbaja, nalta, prom,l;
            nbaja = 0;
            nalta = 5;
            pp = 0;
            prom = 0;
            Console.WriteLine("ingresa el tamaño del vector");
            n = int.Parse(Console.ReadLine());
            float[] vector = new float[n];
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine("digita un numero");
                l = float.Parse(Console.ReadLine());
                vector[i] = l;
                if ((vector[i] < 0) ^ (vector[i] > 5))
                {
                    Console.WriteLine("este dato es erroneo");
                }
                else
                {
                 
                    if (vector[i]>nalta)
                    {
                        nalta = vector[i];
                    }
                    if (vector[i]<nbaja)
                    {
                        nbaja = vector[i];
                    }
                    if (vector[i]<3)
                    {
                        pp = pp + 1;
                    }
                }

                prom = prom + vector[i];
            }
            prom = prom / n;

            Console.WriteLine("las notas de los estudiantes son:");
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine(vector[i]);
            }
            Console.WriteLine("la nolta mas alta del grupo es:" + nalta);
            Console.WriteLine("la nota mas baja es:" + nbaja);
            Console.WriteLine("la nota promedio es:" + prom);
            Console.WriteLine("las personas que perdieron son:" + pp);
           
        }
    }
}
