﻿using System;

namespace ejercicio_13
{
    class Program
    {
        static void Main(string[] args)
        {
            //Se tiene un vector de 365 elementos, cada elemento corresponde a la estación para ese
            // día(V - Verano, I - Invierno, O - Otoño, P - Primavera).Calcular el número de días de verano
            //durante el año.
            int n,verano;
            char tiempo;
            Console.WriteLine("ingresa el tamaño del vector");
            n = char.Parse(Console.ReadLine());
            char[] vector1 = new char[n];
            verano = 0;
            //llenar vec1
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine("ingrese una letra correpondiente a :");
                Console.WriteLine("si es verani V o v");
                Console.WriteLine(" I - Invierno");
                Console.WriteLine("O - Otoño");
                Console.WriteLine(" P - Primavera");
                

                tiempo = char.Parse(Console.ReadLine());
                vector1[i] = tiempo;
                if ((vector1[i]=='v' ) ^ (vector1[i]=='V'))
                {
                    verano=verano + 1;
                }
            }

            Console.WriteLine("hay" + verano + "dias de verano en l año");
        }
    }
}
