﻿using System;

namespace ejercicio_4
{
    class Program
    {
        static void Main(string[] args)
        {
            int n, may, pos,prome, num;
            Console.WriteLine("ingresa el tamaño del vector");
            n = int.Parse(Console.ReadLine());
            int[] vector = new int[n];
            may = 0;
            prome = 0;
            pos = 0;
            for(int i=0;i<n;i++)
            {
                Console.WriteLine("ingresa un numero");
                num = int.Parse(Console.ReadLine());
                vector[i] = num;
                if (vector[i] > may) ;
                {
                    may = vector[i];
                    pos = i;
                }
            }  
            for(int i=0;i<n;i++)
            {
                Console.WriteLine(vector[i]);
            }
            prome = prome / n;
            Console.WriteLine("el promedio de los valores del vector es:" + prome);
            Console.WriteLine("el numero mayor es:" + may);
            Console.WriteLine("los numeros positivos son" + pos);
        }
    }
}
