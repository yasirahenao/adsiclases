﻿using System;

namespace ejercicio_15
{
    class Program
    {
        static void Main(string[] args)
        {
            /*15. Teniendo un vector de 144 elementos numéricos enteros diferentes, realice lo
            siguiente:
           - Buscar el elemento mayor y en qué posición lo encontró. - Sumar los
            elementos almacenados en las posiciones pares y mostrar la suma. - Buscar
             cuántos elementos del vector son mayores de 80 y menores de 120. - Hallar
              cuántos elementos del vector son múltiplos de 7. - Mostrar los elementos del
            vector de forma inversa.
           */
            int n, num, may = 0, posicion = 0, par = 0,cont=0,sie=0;
            Console.WriteLine("ingresa el tamaño del vector");
            n = int.Parse(Console.ReadLine());
            int[] vector = new int[n];

            //Llenar el vector
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine("Ingrese un número");
                num = int.Parse(Console.ReadLine());
                vector[i] = num;
                if (vector[i] > may)
                {
                    may = vector[i];
                    posicion = i;
                }
                if (i == 0)
                {

                }
                else
                {
                    if (i % 2 == 0)
                    {
                        par = par + vector[i];
                    }
                }
                if ((vector[i] > 80) & (vector[i] < 120))
                {
                    cont = cont+ 1;
                }
                if (vector[i] % 7 == 0)
                {
                    sie = sie + 1;
                }
            }
            //Mostrar vector
            Console.WriteLine("El vector es: ");
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine(vector[i]);
            }
            //Mostrar vector al revés
            Console.WriteLine("El vector al revés es: ");
            for (int i = (n - 1); i >= 0; i--)
            {
                Console.WriteLine(vector[i]);
            }
            //
            Console.WriteLine("El número mayor es " + may + " y está en la posición " + posicion);
            Console.WriteLine("La suma de los elementos almacenados en posiciones pares es: " + par);
            Console.WriteLine("Hay " + cont + " elementos del vector que son mayores de 80 y menores de 120");
            Console.WriteLine("En el vector hay " + sie + " multiplos de 7");
        }
    }
}
