﻿using System;

namespace ejercicio_7
{
    class Program
    {
        static void Main(string[] args)
        {
            //7. En vector de 40 elementos numéricos llamado totales, se requiere ir sumando y mostrando
            // cada elemento, siempre y cuando sea mayor al primer elemento y menor al elemento 25.
            // Finalmente, muestre el total de los elementos que fueron sumados.

            int n, l,suma;
            Console.WriteLine("ingresa el tamaño del vector");
            n = int.Parse(Console.ReadLine());
            int[] totales = new int[n];
            suma = 0;
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine("Escriba un número");
                l = int.Parse(Console.ReadLine());
                totales[i] = l;
                if ((totales[i] > totales[0]) & (totales[i] < 25))
                {
                    suma = suma + totales[i];
                    Console.WriteLine(totales[i]);
                }
            }

            Console.WriteLine("El vector es: ");
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine(totales[i]);
            }
            Console.WriteLine("El total de los elementos sumados es: " + suma);

        }
    }
}
