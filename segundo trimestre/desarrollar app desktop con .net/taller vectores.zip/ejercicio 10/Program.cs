﻿using System;

namespace ejercicio_10
{
    class Program
    {
        static void Main(string[] args)
        {
            //Cargar 2 vectores, uno con los códigos de los estudiantes que perdieron C, el segundo con
            // los códigos de los estudiantes que perdieron Java. Se pide crear otro arreglo formado por los
            //códigos de los estudiantes que perdieron ambas materias. Mostrar el arreglo resultante.
            int nc,nj,num,j,aux=0;
            Console.WriteLine("ingresa la cantidad de estudiantes que perdieron c");
            nc = int.Parse(Console.ReadLine());

            Console.WriteLine("ingresa la cantidad de estudiantes que perdieron java");
            nj = int.Parse(Console.ReadLine());

            int[] c = new int[nc];
            int[] vectorjava = new int[nj];
            int[] ambas = new int[(nc+nj)];
            j = 0;
            //nc
            for (int i = 0; i < nc; i++)
            {
                Console.WriteLine(" ingresa los codigos de estudiantes que perdieron c");
                num = int.Parse(Console.ReadLine());
                c[i]= num;
            }
            //nj
            for (int i = 0; i < nj; i++)
            {
                Console.WriteLine("ingresa el codigo de estudiantes que perdieron java");
                num = int.Parse(Console.ReadLine());
                vectorjava[i] = num;
            }
            //ambas 
            for (int i = 0; i < nc; i++)
            {
                for (int m = 0; m < nj ; m++)
                {
                    if (c[i]==vectorjava[m])
                    {
                        ambas[aux] = c[i];
                            aux++;
                    }
                }
            }
            Console.WriteLine("los codigos c son:");
            for (int i = 0; i < nc ; i++)
            {
                Console.WriteLine(c[i]);
            }
            Console.WriteLine("los codigos de java son:");
            for (int i = 0; i < nj; i++) 
            {
                Console.WriteLine(vectorjava[i]);
            }
            Console.WriteLine("el vector ambas es:");
            for (int i = 0; i < (nc+nj); i++)
            {
                Console.WriteLine(ambas[i]);
            }
        }
    }
}
