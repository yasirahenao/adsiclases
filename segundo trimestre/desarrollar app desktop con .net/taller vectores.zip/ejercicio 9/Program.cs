﻿using System;

namespace ejercicio_9
{
    class Program
    {
        static void Main(string[] args)
        {
            //Crear 2 vectores de &quot; N & quot; posiciones cada uno.Con el resultado de la multiplicación de
            //elemento por elemento entre cada vector, formar otro arreglo; muestre posteriormente, 
            //los elementos del vector resultante.
            int n,l;
            Console.WriteLine("ingresa el tamaño de los vectores");
            n = int.Parse(Console.ReadLine());
            int[] vector1 = new int[n];
            int[] vector2 = new int[n];
            int[] RE = new int[n];
            for (int i = 0; i < n ; i++)
            {
                Console.WriteLine("digita un numero");
                l=int.Parse(Console.ReadLine());
                vector1[i] = l;
            }
           Console.WriteLine("el vector 1 es:");
            
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine(vector1[i]);
                //2
            }
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine("digita un numero");
                l = int.Parse(Console.ReadLine());
                vector2[i] = l;
            }
            Console.WriteLine("el vector 2 es:");
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine(vector2[i]);
            }
            //.
            for (int i = 0; i < n; i++)
            {
                
                RE[i] = vector1[i] * vector2[i];
            }
            Console.WriteLine("el vector sesultante es:");
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine(RE[i]);
            }
        }
    }
}
