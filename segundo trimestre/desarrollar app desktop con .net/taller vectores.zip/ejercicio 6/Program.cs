﻿using System;
using System.Net.Sockets;

namespace ejercicio_6
{
    class Program
    {
        static void Main(string[] args)
        {
            //De los 50 elementos de un vector, muestre cuántos son: pares, impares, negativos y
            //positivos.
            int n,l, par, impar, neg,pos,cero;
            Console.WriteLine("ingresa el tamaño del vector");
            n = int.Parse(Console.ReadLine());
            int[] vector = new int[n];
            par = 0;
            impar = 0;
            neg = 0;
            pos = 0;
            cero = 0;
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine("Escriba un número");
                n = int.Parse(Console.ReadLine());
                vector[i] = n;

                if (vector[i] == 0)
                {
                    cero = cero + 1;
                }
                else
                {
                    if (vector[i] > 0)
                    {
                        pos = pos + 1;
                    }
                    else
                    {
                        neg = neg + 1;
                    }
                    if (vector[i] % 2 == 0)
                    {
                        par = par + 1;
                    }
                    else
                    {
                        impar = impar + 1;
                    }
                }
            }

            for (int i = 0; i < n; i++)
            {
                Console.WriteLine(vector[i]);
            }

            Console.WriteLine("Los números pares son: " + par);
            Console.WriteLine("Los números impares son: " + impar);
            Console.WriteLine("Los números positivos son: " + pos);
            Console.WriteLine("Los números negativos son: " + neg);


        }
    }
}
