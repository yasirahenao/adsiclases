﻿using System;
using System.Globalization;

namespace ejercicio_1
{
    class Program
    {
        static void Main(string[] args)
        {
            int n, i = 0, num,l=0 ;
            Console.WriteLine("ingresa el tamaño del vector");
            n = int.Parse(Console.ReadLine());
            int[] vector = new int[n];
            while (i<(n))
            {
                Console.WriteLine("digita un numero");
                num = int.Parse(Console.ReadLine());
                vector[i] = num;
                i++;
            }
            while (l<(n))
            {
                Console.WriteLine(vector[l]);
                l++;
            }


        }
    }
}
