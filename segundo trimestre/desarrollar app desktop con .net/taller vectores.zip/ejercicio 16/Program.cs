﻿using System;

namespace ejercicio_16
{
    class Program
    {
        static void Main(string[] args)
        {
            /*16. Se tiene un vector de 125 elementos con valores numéricos, realice lo
                siguiente:
                - Hallar y mostrar el valor promedio del vector. - Leer un valor x y
                buscar en que posición del vector se encuentra. - Llene un vector con
                los elementos de las posiciones impares. - Busque cuántos elementos
                del vector son múltiplos de 3 y positivos.
             */

            int n, j, pro = 0, x, aux = -1, h = 0, mul3 = 0;
            Console.WriteLine("ingresa el tamaño de los vectores");
            n = int.Parse(Console.ReadLine());
            int[] vector = new int[n];
            int[] impares = new int[n / 2];
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine("ingresa un numero");
                j = int.Parse(Console.ReadLine());
                vector[i] = j;
                pro = pro + j;
            }


            Console.WriteLine("ingresa el valor x");
            x = int.Parse(Console.ReadLine());
            pro = pro / n;

            for (int i = 0; i < n; i++)

            {
                if (vector[i] == x)
                {
                    aux = i;
                }

                if (i % 2 == 1)
                {
                    impares[h] = vector[i];
                    h++;
                }
                if (vector[i] % 3 == 0 & vector[i] > 0)
                {
                    mul3 = mul3 + 1;

                }
            }
            if (aux == -1)
            {
                Console.WriteLine("el valor x nose encuentra");
            }
            else
            {
                Console.WriteLine("la posicion en que se encuentra x es:" + aux);
            }
            Console.WriteLine("el vector es:");
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine(vector[i]);
            }
            Console.WriteLine("el vector de las posiciones impares es:");
            for (int i = 0; i < n / 2; i++)
            {
                Console.WriteLine(impares[i]);
            }
            Console.WriteLine("el valor promedio del vector es:" + pro);
            Console.WriteLine("los numeros multiplos de 3 y positivos son:" + mul3);
        }
    }
}
