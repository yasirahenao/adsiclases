﻿using System;
using System.Globalization;

namespace ejercicio_11
{
    class Program
    {
        static void Main(string[] args)
        {
            //11. Lea un vector S de N elementos e inviértalo. Utilice otro Vector.
            int n, num,j;
            Console.WriteLine("ingresa el tamaño de los vectores");
            n = int.Parse(Console.ReadLine());
            int[] s = new int[n];
            int[] sinvertido = new int[n];
            
            //llenars
            for (int i = 0; i < n ; i++)
            {
                Console.WriteLine("ingrese un numero");
                num = int.Parse(Console.ReadLine());
                s[i]= num;
            }
            //mostrar s
            Console.WriteLine("el vector s es:");
            for (int i = 0; i < n ; i++)
            {
                Console.WriteLine(s[i]);
            }
            j = n - 1;
            //llenar s inv
            for (int i = 0; i < n; i++)
            {
                sinvertido[j] = s[i];
                j--;
            }
            //mostrar s inv
            Console.WriteLine("El vector S invertido es: ");
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine(sinvertido[i]);
            }
        }
    }
}
