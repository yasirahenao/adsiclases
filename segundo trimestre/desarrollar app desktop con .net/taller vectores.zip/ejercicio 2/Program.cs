﻿using System;

namespace ejercicio_2
{
    class Program
    {
        static void Main(string[] args)
        {
            int n, num=2;
            Console.WriteLine("ingresa el tamaño del vector");
            n = int.Parse(Console.ReadLine());
            int[] vector = new int[n];
            for (int i=0; i<n; i++)
            {
                vector[i] = num;
                num = num + 2;
            }
            Console.WriteLine("el vector es:");
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine(vector[i]);
            }


        }
    }
}
