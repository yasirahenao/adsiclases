﻿using System;

namespace ejercicio_5
{
    class Program
    {
        static void Main(string[] args)
        /*Leer un vector de N elementos numéricos enteros y
        posteriormente:
        • Mostrar cuántas veces se repite el número 10.
        • Sume los elementos de las posiciones pares.
        • Muestre los elementos del vector empezando por el último elemento.
       */
        {
            int n,l, diez=0,suma=0;
            Console.WriteLine("ingresa el tamaño del vector");
            n = int.Parse(Console.ReadLine());
            int[] vector = new int[n];
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine("escribe un numero");
                l = int.Parse(Console.ReadLine());
                vector[i] = n;
                if (n==0)
                {
                    diez = diez + 1;
                }
                if (i==0)
                {

                }
                else
                {
                    if (i%2==0)
                    {
                        suma = suma + vector[1];
                    }
                }
            }
            Console.WriteLine("el vector es:");
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine(vector[i]);
            }
            Console.WriteLine("el vector al revez es:");
            for (int i = n -1; i >=0; i--)
            {
                Console.WriteLine(vector[i]);
            }
            Console.WriteLine("el numero 10 se repite" + diez + " veces");
            Console.WriteLine("la suma de las pocisiones pares es:" + suma);
        }
    }
}
